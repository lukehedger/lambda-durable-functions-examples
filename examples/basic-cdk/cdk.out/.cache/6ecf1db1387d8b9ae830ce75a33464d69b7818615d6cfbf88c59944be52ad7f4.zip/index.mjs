var o=async()=>{console.log("hello from Lambda")};export{o as handler};
//# sourceMappingURL=index.mjs.map
